package com.example.demo1_try5;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Demo1Try5ApplicationTests {

    @Test
    void contextLoads() {
    }

}
