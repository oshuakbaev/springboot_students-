package com.example.demo1_try5.model;

import jakarta.persistence.*;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
@Entity
@Table
public class Student {
    @Id
    @SequenceGenerator(name = "student_sequence", sequenceName = "student_sequence",allocationSize = 1 )
    @GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "student_sequence")

    private Integer id;
    private String name;
    private double gpa;

    public Student(Integer id, String name, double gpa) {
        this.id = id;
        this.name = name;
        this.gpa = gpa;
    }

    public Student() {

    }
}
