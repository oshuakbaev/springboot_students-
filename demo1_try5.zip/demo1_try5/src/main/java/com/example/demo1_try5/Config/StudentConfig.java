package com.example.demo1_try5.Config;

import com.example.demo1_try5.Repository.StudentRepository;
import com.example.demo1_try5.model.Student;
import org.springframework.boot.CommandLineRunner;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import java.util.List;

@Configuration
public class StudentConfig {
    @Bean
    CommandLineRunner commandLineRunner(StudentRepository repository){
        return args -> {
           Student olzh = new Student(1,"Olzh",4.0);
            Student akylbek = new Student(2,"Akylbek",5.0);

            repository.saveAll(List.of(olzh,akylbek));
        };
    }
}
